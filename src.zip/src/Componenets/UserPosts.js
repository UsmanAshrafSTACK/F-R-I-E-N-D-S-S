import React from 'react'

export default function UserPosts() {
    
    return (
             {/* {mainPage && <div className="allPost">
          {post.map((e, index) => (
            <Card sx={{ maxWidth: 345 }} key={index}>
              <CardHeader
                name={userInfo.firstName + " " + userInfo.lastName}
                time={e.dateString + " " + e.timeString}
                src={userInfo.userPhoto}
              />
              {e.postPicture !== "false" && <CardMain src={e.postPicture} />}
              <CardFooter caption={e.postCaption} />
            </Card>
          ))}
        </div>} */}
    )
}

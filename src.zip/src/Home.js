import React from 'react'
import MiniDrawer from './Componenets/MiniDrawer'

export default function Home() {
  return (
   <MiniDrawer/>
  )
}
